sap.ui.define(
    [
        "com/amadeus/fiori/ppm/commons/controller/BaseController"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.amadeus.fiori.ppm.ipf.deiverables.masscreation.controller.App", {
        onInit() {
        }
      });
    }
  );
  