/* global QUnit */

sap.ui.require(["com/amadeus/fiori/ppm/ipf/deiverables/masscreation/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
