sap.ui.define([
	"comamadeusfiorippmipfdeiverables/mass_creation/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
